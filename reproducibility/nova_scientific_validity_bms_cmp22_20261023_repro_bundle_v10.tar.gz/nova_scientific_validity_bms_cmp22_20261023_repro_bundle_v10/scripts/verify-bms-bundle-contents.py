#!/usr/bin/env python3
import argparse, hashlib, json, pathlib

def sha256(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1024*1024), b''): h.update(c)
    return h.hexdigest()

def main():
    ap=argparse.ArgumentParser(description='Verify a NOVA BMS bundle without external paths.')
    ap.add_argument('--bundle-dir', required=True, type=pathlib.Path)
    args=ap.parse_args(); b=args.bundle_dir
    if not b.is_dir(): raise SystemExit('FAIL: bundle_dir_missing')
    sums=b/'SHA256SUMS'
    if not sums.is_file(): raise SystemExit('FAIL: SHA256SUMS_missing')
    bad=[]; count=0
    for line in sums.read_text().splitlines():
        if not line.strip(): continue
        exp,name=line.split(None,1); p=b/name.lstrip('*'); count+=1
        if not p.is_file() or sha256(p)!=exp: bad.append(name)
    if bad: raise SystemExit('FAIL: internal_sha256_mismatch '+','.join(bad))
    manifest=b/'manifest.json'; pending=b/'EXTERNAL_REPRODUCTION_PENDING.json'
    if not manifest.is_file() or not pending.is_file(): raise SystemExit('FAIL: required_metadata_missing')
    m=json.loads(manifest.read_text()); q=json.loads(pending.read_text())
    if q.get('status') != 'EXTERNAL_REPRODUCTION_PENDING': raise SystemExit('FAIL: pending_status_changed')
    print(json.dumps({'status':'PASS','sha_entries':count,'bundle_version':m.get('bundle_version'),'formal_pass':False,'external_verified':False},sort_keys=True))

if __name__=='__main__': main()
