#!/usr/bin/env python3
import argparse, json, pathlib

REQUIRED = (
    'bms_row_range_audit_20261023.json',
    'bms_xy_blind_comparison_20261023.json',
    'bms_independent_engine_recalc_20261023.json',
)

def main():
    ap = argparse.ArgumentParser(description='Fail-closed preflight for the NOVA BMS bundle runner.')
    ap.add_argument('--bundle-dir', required=True, type=pathlib.Path)
    ap.add_argument('--output', required=True, type=pathlib.Path)
    a = ap.parse_args()
    missing = [n for n in REQUIRED if not (a.bundle_dir / n).is_file()]
    result = {
        'schema': 'NOVA_BMS_BUNDLE_RERUN_PREFLIGHT_V1',
        'status': 'READY' if not missing else 'BLOCKED_REQUIRED_INPUTS_MISSING',
        'required_inputs': list(REQUIRED),
        'missing_inputs': missing,
        'execution_complete': False,
        'external_verified': False,
        'formal_pass': False,
    }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, sort_keys=True))
    raise SystemExit(0 if not missing else 2)

if __name__ == '__main__':
    main()
