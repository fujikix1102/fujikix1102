# Third-party execution handoff

## Artifact

- Archive: `nova_scientific_validity_bms_cmp22_20261023_repro_bundle_v6.tar.gz`
- Archive SHA-256: recorded in the adjacent `.sha256` sidecar after archive creation; do not infer it from an older bundle.
- Reproduction manifest: `manifest.json`
- Current formal status: `formal_pass=false`

## Requested independent evidence

The executor should report:

1. operating system and Python/runtime versions;
2. raw input URLs and input SHA-256 values;
3. runner or script SHA-256;
4. output SHA-256 and the individual gate results;
5. whether the 60-minute primary and 30/120-minute sensitivity analyses agree;
6. any deviations, missing inputs, or manual interventions.

An automated CI run alone does not establish human third-party execution. Until a human executor supplies the evidence above, `external_verified=false` and `formal_pass=false` remain in force.

The current artifact is not considered publicly available until this archive is uploaded to a reachable release asset or other approved public distribution endpoint.
