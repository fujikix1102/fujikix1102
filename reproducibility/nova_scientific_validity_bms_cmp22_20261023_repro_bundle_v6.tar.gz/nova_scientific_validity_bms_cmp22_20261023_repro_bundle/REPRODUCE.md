# Reproduction protocol

## 1. Acquire inputs

Use the official BMS API in two ranges because the full response can exceed a short request timeout:

- `https://midcdmz.nlr.gov/apps/data_api.pl?site=BMS&begin=20230601&end=20230615`
- `https://midcdmz.nlr.gov/apps/data_api.pl?site=BMS&begin=20230616&end=20230630`

Also obtain the calibration records for serials `080017` and `140043` from the URLs recorded in the artifacts.

## 2. Validate inputs before analysis

Confirm that each BMS response contains the expected header fields, 21,600 data rows, MST timestamps, and both CMP22 variables. Concatenate only after both parts pass validation. Record the input SHA-256 values.

## 3. Primary analysis

Use the same local MST minute key for both channels and retain only paired values with zenith angle `< 60` degrees. Calculate mean difference, MAE, RMSE, Pearson correlation, Bland–Altman limits, daily means, and proportional-bias diagnostics.

## 4. Dependence and uncertainty

Do not treat minutes as IID. Use the preregistered 60-minute contiguous-block analysis and report 30- and 120-minute sensitivity results. Keep calibration uncertainty, field representativeness, and covariance as separate components. Missing components must produce `UNRESOLVED`, never zero.

## 5. Evidence submission

Return the operating environment, input SHA-256 values, runner SHA-256, result SHA-256, execution log, deviations, and manual interventions. Automated CI alone does not establish human third-party execution.

Expected status until all evidence is supplied: `external_verified=false`, `formal_pass=false`.
