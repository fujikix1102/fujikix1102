# NOVA BMS CMP22 Scientific Validity Reproduction Bundle

Scope: official NLR/MIDC BMS `Global CMP22 (vent/cor)` versus `Global CMP22-1 (cor)` with May–July 2023 independent periods.

Sources: https://midcdmz.nlr.gov/apps/data_api.pl and https://midcdmz.nlr.gov/apps/fmpxml.pl; external covariate: Open-Meteo Archive API at 39.742,-105.18.

Reproduction: verify SHA-256 values, apply zenith <60 degrees, preserve serial dependence, run 60-minute primary plus 30/120-minute sensitivities, then run month/day hierarchical bootstrap and evidence gates.

Conclusion: numerical agreement is verified for specified checks. Field uncertainty, covariance, external third-party reproduction, and formal statistical validity remain unresolved. `formal_pass=false` is intentional.


## Third-party evidence gate

Use  after an independent human rerun. The validator fails closed unless required execution evidence, input/runner/result SHA-256 values, and explicit human confirmation are present. It also rejects premature .
